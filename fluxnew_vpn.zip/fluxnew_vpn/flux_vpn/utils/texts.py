"""Форматирование и тексты сообщений."""
from __future__ import annotations

import html
from datetime import datetime
from zoneinfo import ZoneInfo

E = html.escape


def fmt_dt(ts: int | None, tz: str) -> str:
    if not ts:
        return "—"
    return datetime.fromtimestamp(ts, ZoneInfo(tz)).strftime("%d.%m.%Y %H:%M")


def fmt_date(ts: int | None, tz: str) -> str:
    if not ts:
        return "—"
    return datetime.fromtimestamp(ts, ZoneInfo(tz)).strftime("%d.%m.%Y")


def _plural(n: int, one: str, few: str, many: str) -> str:
    n10, n100 = n % 10, n % 100
    if n10 == 1 and n100 != 11:
        return one
    if 2 <= n10 <= 4 and not 12 <= n100 <= 14:
        return few
    return many


def fmt_days(n: int) -> str:
    return f"{n} {_plural(n, 'день', 'дня', 'дней')}"


def fmt_remaining(seconds: int) -> str:
    if seconds <= 0:
        return "истекла"
    d, rem = divmod(seconds, 86400)
    h, rem = divmod(rem, 3600)
    m = rem // 60
    parts = []
    if d:
        parts.append(f"{d} {_plural(d, 'день', 'дня', 'дней')}")
    if h:
        parts.append(f"{h} ч")
    if not d and m:
        parts.append(f"{m} мин")
    return " ".join(parts) or "меньше минуты"


def fmt_money(amount: int, currency: str) -> str:
    if currency == "RUB":
        return f"{amount} ₽"
    if currency == "XTR":
        return f"{amount} ⭐"
    return f"{amount} {currency}"


STATUS_EMOJI = {"PENDING": "⏳", "PAID": "✅", "EXPIRED": "⌛", "CANCELLED": "🚫", "REFUNDED": "↩️"}
STATUS_RU = {"PENDING": "ожидает оплаты", "PAID": "оплачен", "EXPIRED": "истёк",
             "CANCELLED": "отменён", "REFUNDED": "возвращён"}

# ---------- уведомления ----------

def n_paid(plan_name: str, ends: str) -> str:
    return (f"✅ <b>Оплата получена!</b>\n\nТариф: <b>{E(plan_name)}</b>\n"
            f"Подписка активна до: <b>{ends}</b>\n\n"
            "Ваши подключения готовы — откройте «🔑 Мои подключения».")


def n_extended(ends: str) -> str:
    return f"🔄 <b>Подписка продлена</b>\nНовая дата окончания: <b>{ends}</b>"


def n_vpn_pending() -> str:
    return ("⏳ Оплата прошла, но VPN-панель пока не ответила. Доступ будет выдан автоматически "
            "в ближайшие минуты — мы сообщим вам.")


def n_vpn_ready() -> str:
    return "🔑 Подключения готовы! Откройте «Мои подключения»."


def n_expire(kind: str, ends: str) -> str:
    return {
        "EXPIRE_3D": f"⏰ Подписка закончится через 3 дня — <b>{ends}</b>. Продлите заранее, чтобы не потерять доступ.",
        "EXPIRE_1D": f"⚠️ Подписка закончится меньше чем через сутки — <b>{ends}</b>.",
        "EXPIRE_TODAY": f"❗️ Сегодня подписка заканчивается — <b>{ends}</b>. Продлите её, чтобы не остаться без VPN.",
        "EXPIRED": "🔴 <b>Подписка закончилась.</b> Доступ отключён. Нажмите «Продлить», чтобы вернуть VPN.",
    }[kind]


def n_promo(days: int, ends: str) -> str:
    return f"🎟 Промокод применён: <b>+{fmt_days(days)}</b>.\nПодписка активна до <b>{ends}</b>."


def n_referral(days: int) -> str:
    return (f"🎁 Ваш реферал совершил покупку! На бонусный баланс начислено <b>{fmt_days(days)}</b>. "
            "Применить их можно в разделе «Реферальная программа».")
