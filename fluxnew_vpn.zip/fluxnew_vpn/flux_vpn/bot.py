"""Точка входа FLUX VPN: python bot.py"""
from __future__ import annotations

import asyncio
import logging
import sys

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from config import BASE_DIR, ConfigError, Settings, abs_path
from database import Database
from services.container import Services
from utils.logging import setup_logging

log = logging.getLogger("flux")


async def build_services(settings: Settings, bot: Bot, db: Database) -> Services:
    from payments.cryptobot import CryptoBotProvider
    from payments.donatealerts import DonateAlertsProvider
    from payments.telegram_stars import StarsProvider
    from services.fulfillment import Fulfillment
    from services.notifications import Notifier
    from services.orders import OrderService
    from services.plans import PlanService
    from services.promo import PromoService
    from services.referrals import REF_BONUS_KEY, ReferralService
    from services.scheduler import Scheduler
    from services.settings import SettingsService
    from services.subscriptions import SubscriptionService
    from services.users import UserService
    from vpn.nodes import NodeRegistry
    from vpn.subscriptions import VpnManager

    kv = SettingsService(db)
    if await kv.get(REF_BONUS_KEY) is None:
        await kv.set(REF_BONUS_KEY, str(settings.referral_default_bonus_days))
    users, plans, subs = UserService(db), PlanService(db), SubscriptionService(db)
    from models import Provider
    orders = OrderService(db, plans, {Provider.STARS: settings.order_ttl_stars_min,
                                      Provider.CRYPTOBOT: settings.order_ttl_crypto_min,
                                      Provider.DONATEALERTS: settings.order_ttl_donate_min})
    registry = NodeRegistry.from_settings(db, settings)
    await registry.sync_db()
    vpn = VpnManager(db, registry)
    notifier = Notifier(bot, db, settings.admin_ids)
    fulfillment = Fulfillment(db, orders, subs, vpn, notifier, users, settings.timezone)

    svc = Services(settings=settings, kv=kv, db=db, bot=bot, users=users, plans=plans, subs=subs, orders=orders,
                   promo=PromoService(db), referrals=None, vpn=vpn, registry=registry,
                   fulfillment=fulfillment, notifier=notifier)
    svc.referrals = ReferralService(db, svc.bot_username)

    if settings.stars_enabled:
        svc.stars = StarsProvider(bot, plans, orders, users, fulfillment)
        svc.providers[Provider.STARS] = svc.stars
    if settings.cryptobot_enabled:
        svc.crypto = CryptoBotProvider(settings.cryptobot_token, settings.cryptobot_network,
                                       settings.cryptobot_assets, orders, users, fulfillment, svc.bot_username)
        svc.providers[Provider.CRYPTOBOT] = svc.crypto
    if settings.donatealerts_enabled:
        svc.donate = DonateAlertsProvider(settings.donatealerts_url, settings.donatealerts_client_id,
                                          settings.donatealerts_client_secret,
                                          str(abs_path(settings.donatealerts_token_file)),
                                          orders, users, fulfillment)
        svc.providers[Provider.DONATEALERTS] = svc.donate
    svc.scheduler = Scheduler(db, orders, subs, vpn, notifier, users, svc.providers, settings.timezone,
                              abs_path(settings.backup_dir), settings.backup_keep, settings.backup_interval_hours)
    return svc


def build_dispatcher(svc: Services) -> Dispatcher:
    from admin import broadcasts, dashboard, payments as adm_payments, promos, settings as adm_settings, statistics
    from admin import users as adm_users
    from handlers import cabinet, connections, menu, promo, referrals, shop, start, support
    from middlewares.throttle import ThrottleMiddleware
    from middlewares.user import UserMiddleware

    dp = Dispatcher(storage=MemoryStorage())
    dp["svc"] = svc
    for observer in (dp.message, dp.callback_query):
        observer.outer_middleware(UserMiddleware(svc))
        observer.outer_middleware(ThrottleMiddleware())
    for r in (start.router, menu.router, shop.router, cabinet.router, connections.router, referrals.router,
              promo.router, support.router, dashboard.router, statistics.router, adm_users.router,
              adm_payments.router, promos.router, adm_settings.router, broadcasts.router):
        dp.include_router(r)
    return dp


async def main() -> None:
    try:
        settings = Settings.load()
        settings.validate_for_run()
    except ConfigError as e:
        print(f"Ошибка конфигурации: {e}", file=sys.stderr)
        sys.exit(2)
    setup_logging(settings.log_level, str(abs_path(settings.log_file)), settings.secrets())
    if settings.vpn_mode == "mock":
        log.warning("VPN_MODE=mock: выдаются ТЕСТОВЫЕ ЗАГЛУШКИ, не рабочие конфигурации")

    bot = Bot(settings.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML,
                                                               link_preview_is_disabled=True))
    db = Database(abs_path(settings.database_path))
    await db.connect()
    await db.migrate(BASE_DIR / "migrations", abs_path(settings.backup_dir))
    svc = await build_services(settings, bot, db)
    dp = build_dispatcher(svc)

    runner = None
    if settings.public_url or (svc.crypto and settings.cryptobot_webhook_secret):
        from payments.webhook import build_app, start_server
        runner = await start_server(build_app(svc.crypto, settings.cryptobot_webhook_secret, svc.vpn),
                                    settings.webhook_host, settings.webhook_port)
    svc.scheduler.start()
    me = await bot.me()
    log.info("FLUX VPN запущен как @%s (провайдеры: %s)", me.username, ", ".join(svc.providers) or "нет")
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await svc.scheduler.stop()
        if runner:
            await runner.cleanup()
        await svc.registry.close()
        for p in (svc.crypto, svc.donate):
            if p:
                await p.http.close()
        await bot.session.close()
        await db.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        pass
