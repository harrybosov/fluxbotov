from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from admin import AdminFilter, AdmStates
from keyboards import back, btn, kb
from models import PROVIDER_TITLES
from utils import clock, texts
from utils.ui import alert, render

router = Router(name="admin_users")
router.message.filter(AdminFilter())
router.callback_query.filter(AdminFilter())
E = texts.E


async def user_card(svc, user: dict) -> tuple[str, object]:
    tz = svc.settings.timezone
    sub = await svc.subs.view(user["id"])
    orders = await svc.db.fetchone("SELECT COUNT(*) c FROM orders WHERE user_id=?", (user["id"],))
    refs = await svc.db.fetchone("SELECT COUNT(*) c FROM referrals WHERE referrer_id=?", (user["id"],))
    lines = [f"👤 <b>Пользователь</b> <code>{user['tg_id']}</code>",
             f"Имя: {E(user.get('first_name') or '—')}" + (f" @{E(user['username'])}" if user.get("username") else ""),
             f"Регистрация: {texts.fmt_dt(user['created_at'], tz)}",
             f"Блокировка: {'🚫 да' if user['is_blocked'] else 'нет'}",
             f"Бонусный баланс: {texts.fmt_days(user['bonus_days'])}",
             f"Заказов: {orders['c']} · Рефералов: {refs['c']}"]
    if sub:
        lines += ["", f"Подписка: {'🟢 активна' if sub['is_active'] else '🔴 истекла'} до {texts.fmt_dt(sub['ends_at'], tz)}",
                  f"Тариф: {sub['plan_id'] or '—'} · VPN синхронизирован: {'да' if not sub['vpn_dirty'] else 'нет ⚠️'}"]
        if sub["vpn_error"]:
            lines.append(f"Ошибка VPN: {E(sub['vpn_error'][:200])}")
    else:
        lines += ["", "Подписки нет"]
    uid = user["id"]
    rows = [[btn("🧾 Заказы", f"adm:u:orders:{uid}"), btn("👥 Рефералы", f"adm:u:refs:{uid}")],
            [btn("✅ Разблокировать" if user["is_blocked"] else "🚫 Заблокировать", f"adm:u:ban:{uid}", style="danger")]]
    if svc.settings.allow_manual_extend:
        rows.append([btn("➕ 7 дней", f"adm:u:add:{uid}:7"), btn("➕ 30 дней", f"adm:u:add:{uid}:30")])
    rows.append([back("adm:users", "🔙 Поиск"), back("adm", "🛠 Админ-панель")])
    return "\n".join(lines), kb(rows)


@router.callback_query(F.data == "adm:users")
async def users_menu(cb: CallbackQuery, state: FSMContext):
    await state.set_state(AdmStates.user_search)
    await render(cb, "👥 <b>Пользователи</b>\n\nОтправьте Telegram ID пользователя.", kb([[back("adm")]]))


@router.message(AdmStates.user_search, F.text)
async def user_search(msg: Message, state: FSMContext, svc):
    raw = msg.text.strip()
    if not raw.lstrip("-").isdigit():
        return await msg.answer("Нужен числовой Telegram ID.")
    user = await svc.users.get_by_tg(int(raw))
    if not user:
        return await msg.answer("Пользователь не найден.", reply_markup=kb([[back("adm")]]))
    await state.clear()
    text, markup = await user_card(svc, user)
    await msg.answer(text, reply_markup=markup)


@router.callback_query(F.data.startswith("adm:u:orders:"))
async def user_orders(cb: CallbackQuery, svc):
    uid = int(cb.data.split(":")[3])
    orders = await svc.orders.list_for_user(uid, 15)
    tz = svc.settings.timezone
    rows = [f"{texts.STATUS_EMOJI[o['status']]} <code>{o['public_id']}</code> {texts.fmt_dt(o['created_at'], tz)} "
            f"{E(o['plan_name'])} {texts.fmt_money(o['amount'], o['currency'])} {PROVIDER_TITLES[o['provider']]}"
            for o in orders]
    await render(cb, "🧾 <b>Заказы</b>\n\n" + ("\n".join(rows) or "—"),
                 kb([[back(f"adm:u:card:{uid}", "🔙 К пользователю")]]))


@router.callback_query(F.data.startswith("adm:u:refs:"))
async def user_refs(cb: CallbackQuery, svc):
    uid = int(cb.data.split(":")[3])
    refs = await svc.referrals.list_for_admin(uid)
    tz = svc.settings.timezone
    rows = [f"• <code>{r['tg_id']}</code> {('@' + E(r['username'])) if r['username'] else ''} "
            f"{texts.fmt_date(r['created_at'], tz)} — "
            + (f"бонус +{r['bonus_days']} дн." if r["reward_order_id"] else "без покупки") for r in refs]
    await render(cb, "👥 <b>Рефералы</b>\n\n" + ("\n".join(rows) or "—"),
                 kb([[back(f"adm:u:card:{uid}", "🔙 К пользователю")]]))


@router.callback_query(F.data.startswith("adm:u:card:"))
async def user_back(cb: CallbackQuery, svc):
    user = await svc.users.get(int(cb.data.split(":")[3]))
    text, markup = await user_card(svc, user)
    await render(cb, text, markup)


@router.callback_query(F.data.startswith("adm:u:ban:"))
async def user_ban(cb: CallbackQuery, svc):
    user = await svc.users.get(int(cb.data.split(":")[3]))
    if svc.settings.is_admin(user["tg_id"]):
        return await alert(cb, "Администратора заблокировать нельзя")
    new = not user["is_blocked"]
    await svc.users.set_blocked(user["id"], new)
    await svc.admin_log(cb.from_user.id, "block" if new else "unblock", str(user["tg_id"]))
    text, markup = await user_card(svc, await svc.users.get(user["id"]))
    await render(cb, text, markup)


@router.callback_query(F.data.startswith("adm:u:add:"))
async def user_add(cb: CallbackQuery, svc):
    if not svc.settings.allow_manual_extend:
        return await alert(cb, "Ручное продление отключено (ALLOW_MANUAL_EXTEND=false)")
    _, _, _, uid, days = cb.data.split(":")
    await svc.fulfillment.grant_days(int(uid), int(days), kind="ADMIN_GRANT", ref=str(clock.now()),
                                     text_builder=lambda ends: f"🎁 Администратор добавил вам {texts.fmt_days(int(days))}. "
                                                               f"Подписка активна до <b>{ends}</b>.")
    user = await svc.users.get(int(uid))
    await svc.admin_log(cb.from_user.id, "manual_extend", str(user["tg_id"]), f"+{days}d")
    text, markup = await user_card(svc, user)
    await render(cb, text, markup)
