"""Базовые типы и интерфейс адаптера VPN-панели."""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


class PanelError(Exception):
    """Любая ошибка панели (сеть, авторизация, ответ success=false, неподдерживаемый протокол)."""


class PanelConnectionError(PanelError): ...
class PanelAuthError(PanelError): ...
class UnsupportedProtocol(PanelError): ...


@dataclass
class ClientState:
    secret: str          # uuid (vless/vmess) / password (trojan, shadowsocks)
    protocol: str        # vless / vmess / trojan / shadowsocks
    label: str           # человекочитаемо, напр. "VLESS + REALITY"
    expiry_ts: int
    enabled: bool
    created: bool = False


@dataclass
class LinkInfo:
    protocol_label: str
    link: str
    is_placeholder: bool = False


class PanelAdapter(ABC):
    """Один адаптер = одна панель 3X-UI (узел). Германия и США могут быть на разных панелях."""

    key: str

    @abstractmethod
    async def ensure_client(self, panel_inbound_id: int, email: str, secret: str | None,
                            expiry_ts: int, enabled: bool, comment: str = "", sub_id: str = "") -> ClientState:
        """Идемпотентно: создаёт клиента, если его нет (по email), иначе обновляет срок/enable."""

    @abstractmethod
    async def get_client(self, panel_inbound_id: int, email: str) -> ClientState | None: ...

    @abstractmethod
    async def build_link(self, panel_inbound_id: int, email: str, secret: str, remark: str) -> LinkInfo: ...

    async def close(self) -> None:  # noqa: B027
        pass
