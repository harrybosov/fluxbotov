"""Связка «подписка в БД» ↔ «клиенты в панелях». Все 6 inbound'ов выдаются одновременно."""
from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from dataclasses import dataclass, field

from utils import clock
from vpn.base import PanelError
from vpn.nodes import NodeRegistry, country_meta

log = logging.getLogger(__name__)


@dataclass
class SyncResult:
    ok: bool
    errors: list[str] = field(default_factory=list)
    synced: int = 0


@dataclass
class ConnectionView:
    inbound_id: int
    node_key: str
    country: str
    position: int
    title: str
    protocol_label: str
    link: str | None
    error: str | None = None
    is_placeholder: bool = False


def client_email(tg_id: int, node_key: str, position: int) -> str:
    return f"flux{tg_id}-{node_key.lower()}{position}"


class VpnManager:
    def __init__(self, db, registry: NodeRegistry):
        self.db = db
        self.registry = registry
        self._locks: dict[int, asyncio.Lock] = defaultdict(asyncio.Lock)

    async def _sub_id(self, user_id: int) -> str:
        """Один subId на все серверы пользователя → панель сама отдаёт ОДНУ общую подписку."""
        import secrets
        async with self.db.tx() as t:
            row = await t.fetchone("SELECT sub_token FROM users WHERE id=?", (user_id,))
            if row and row["sub_token"]:
                return row["sub_token"]
            token = secrets.token_hex(16)
            await t.execute("UPDATE users SET sub_token=? WHERE id=?", (token, user_id))
            return token

    async def sync_user(self, user_id: int) -> SyncResult:
        """Идемпотентно приводит клиентов во всех панелях к состоянию подписки. Не бросает исключений."""
        async with self._locks[user_id]:
            try:
                return await self._sync(user_id)
            except Exception as e:  # noqa: BLE001
                log.exception("sync_user(%s) crashed", user_id)
                return SyncResult(False, [f"internal: {type(e).__name__}"])

    async def _sync(self, user_id: int) -> SyncResult:
        sub = await self.db.fetchone("SELECT * FROM subscriptions WHERE user_id=?", (user_id,))
        user = await self.db.fetchone("SELECT * FROM users WHERE id=?", (user_id,))
        if not sub or not user:
            return SyncResult(True)
        now = clock.now()
        enabled = sub["status"] == "ACTIVE" and sub["ends_at"] > now
        sub_id = await self._sub_id(user_id)
        inbounds = await self.registry.active_inbounds()
        existing = {r["inbound_id"]: r for r in await self.db.fetchall(
            "SELECT * FROM vpn_clients WHERE user_id=?", (user_id,))}
        by_node: dict[str, list[dict]] = defaultdict(list)
        for ib in inbounds:
            by_node[ib["node_key"]].append(ib)
        errors: list[str] = []
        synced = 0

        async def run_node(items: list[dict]) -> int:
            ok = 0
            for ib in items:
                adapter = self.registry.adapter(ib["node_key"])
                email = client_email(user["tg_id"], ib["node_key"], ib["position"])
                prev = existing.get(ib["inbound_id"])
                try:
                    st = await adapter.ensure_client(
                        ib["panel_inbound_id"], email, prev["secret"] if prev else None,
                        sub["ends_at"], enabled, comment=f"FLUX tg:{user['tg_id']}", sub_id=sub_id)
                except PanelError as e:
                    errors.append(f"{ib['node_key']}#{ib['panel_inbound_id']}: {e}")
                    continue
                await self.db.execute(
                    "INSERT INTO vpn_clients(user_id,inbound_id,email,secret,expiry_at,enabled,synced_at) "
                    "VALUES(?,?,?,?,?,?,?) ON CONFLICT(user_id,inbound_id) DO UPDATE SET "
                    "secret=excluded.secret, expiry_at=excluded.expiry_at, enabled=excluded.enabled, "
                    "synced_at=excluded.synced_at",
                    (user_id, ib["inbound_id"], email, st.secret, sub["ends_at"], int(st.enabled), clock.now()))
                if st.label and st.label != ib["protocol"]:
                    await self.db.execute("UPDATE vpn_inbounds SET protocol=? WHERE id=?",
                                          (st.label, ib["inbound_id"]))
                ok += 1
            return ok

        results = await asyncio.gather(*(run_node(v) for v in by_node.values()))
        synced = sum(results)
        if errors:
            await self.db.execute("UPDATE subscriptions SET vpn_error=?, updated_at=? WHERE id=?",
                                  ("; ".join(errors)[:500], clock.now(), sub["id"]))
            return SyncResult(False, errors, synced)
        # сбрасываем dirty только если подписку не меняли во время синхронизации
        await self.db.execute(
            "UPDATE subscriptions SET vpn_dirty=0, vpn_error=NULL WHERE id=? AND ends_at=? AND status=?",
            (sub["id"], sub["ends_at"], sub["status"]))
        return SyncResult(True, [], synced)

    async def connections(self, user_id: int) -> list[ConnectionView]:
        """Подключения ТОЛЬКО указанного пользователя (чужие конфигурации недоступны по построению)."""
        sub = await self.db.fetchone("SELECT * FROM subscriptions WHERE user_id=?", (user_id,))
        if not sub or sub["status"] != "ACTIVE" or sub["ends_at"] <= clock.now():
            return []
        clients = {r["inbound_id"]: r for r in await self.db.fetchall(
            "SELECT * FROM vpn_clients WHERE user_id=? AND enabled=1", (user_id,))}
        views: list[ConnectionView] = []
        for ib in await self.registry.active_inbounds():
            flag, ru, en = country_meta(ib["country"])
            c = clients.get(ib["inbound_id"])
            v = ConnectionView(ib["inbound_id"], ib["node_key"], ib["country"], ib["position"],
                               f"{flag} {ru} — Подключение {ib['position']}", ib["protocol"] or "—", None)
            if c is None:
                v.error = "Подключение ещё готовится"
            else:
                try:
                    info = await self.registry.adapter(ib["node_key"]).build_link(
                        ib["panel_inbound_id"], c["email"], c["secret"], f"FLUX {en} {ib['position']}")
                    v.link, v.protocol_label, v.is_placeholder = info.link, info.protocol_label, info.is_placeholder
                except PanelError as e:
                    log.warning("build_link failed: %s", e)
                    v.error = "Панель временно недоступна"
            views.append(v)
        return views

    async def feed(self, token: str) -> tuple[int, dict, str]:
        """Единая подписка: base64 от списка ссылок (формат, понятный v2rayNG/Hiddify/Streisand/Happ и др.).
        Возвращает (HTTP-статус, заголовки, тело). Неактивная подписка → пустой список."""
        import base64
        user = await self.db.fetchone("SELECT * FROM users WHERE sub_token=?", (token or "",))
        if not user or user["is_blocked"]:
            return 404, {}, ""
        sub = await self.db.fetchone("SELECT * FROM subscriptions WHERE user_id=?", (user["id"],))
        links = [v.link for v in await self.connections(user["id"]) if v.link]
        title = base64.b64encode("FLUX VPN".encode()).decode()
        headers = {"profile-title": "base64:" + title, "profile-update-interval": "6",
                   "subscription-userinfo": f"upload=0; download=0; total=0; expire={sub['ends_at'] if sub else 0}",
                   "Cache-Control": "no-store"}
        return 200, headers, base64.b64encode("\n".join(links).encode()).decode()

    async def count_clients(self, user_id: int) -> int:
        r = await self.db.fetchone("SELECT COUNT(*) c FROM vpn_clients WHERE user_id=? AND enabled=1", (user_id,))
        return r["c"]
