"""Адаптер панели 3X-UI. Поддерживает два API (определяется автоматически):

  • СОВРЕМЕННЫЙ (панели 3.x): /panel/api/clients/*  — add, update/:email, :email/attach, get/:email, links/:email
  • СТАРЫЙ (2.x):             /panel/api/inbounds/addClient, updateClient/:clientId

Вход: CSRF-токен (GET /csrf-token → X-CSRF-Token) + POST /login, либо Authorization: Bearer <токен API>.
Ответы панели: {"success": bool, "msg": str, "obj": ...}.
Справка по API: https://docs.sanaei.dev/docs/reference/api/clients/ (и /panel/api-docs в самой панели).
Проверка подключения: `python -m scripts.check_xui`.
"""
from __future__ import annotations

import asyncio
import base64
import json
import logging
import secrets as _secrets
import time
import uuid
from typing import TYPE_CHECKING, Any, Protocol
from urllib.parse import quote, urlsplit, urlunsplit

if TYPE_CHECKING:  # импорт только для аннотаций
    from config import NodeConfig

from vpn import links
from vpn.base import (ClientState, LinkInfo, PanelAdapter, PanelAuthError, PanelConnectionError,
                      PanelError, UnsupportedProtocol)

log = logging.getLogger(__name__)
SUPPORTED = {"vless", "vmess", "trojan", "shadowsocks"}
BAD_HOSTS = {"", "0.0.0.0", "127.0.0.1", "localhost", "::", "::1"}


class Transport(Protocol):
    async def request(self, method: str, url: str, *, json_body: Any = None,
                      form: dict | None = None, headers: dict | None = None) -> tuple[int, Any, str]: ...
    async def close(self) -> None: ...


class AiohttpTransport:
    def __init__(self, verify_ssl: bool = True, timeout: float = 20.0):
        self._verify = verify_ssl
        self._timeout = timeout
        self._session = None

    async def _get(self):
        import aiohttp
        if self._session is None or self._session.closed:
            # unsafe=True: иначе aiohttp не сохраняет cookie для IP-адресов (панель часто открыта по IP)
            kw = {} if self._verify else {"connector": aiohttp.TCPConnector(ssl=False)}
            self._session = aiohttp.ClientSession(
                cookie_jar=aiohttp.CookieJar(unsafe=True),
                timeout=aiohttp.ClientTimeout(total=self._timeout), **kw)
        return self._session

    async def request(self, method, url, *, json_body=None, form=None, headers=None):
        import aiohttp
        session = await self._get()
        try:
            async with session.request(method, url, json=json_body, data=form, headers=headers) as r:
                text = await r.text()
                try:
                    body = json.loads(text)
                except ValueError:
                    body = None
                return r.status, body, text
        except (aiohttp.ClientError, asyncio.TimeoutError) as e:
            raise PanelConnectionError(f"{type(e).__name__}: {e}") from e

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()


def _client_key(protocol: str, client: dict) -> str:
    return {"vless": client.get("id"), "vmess": client.get("id"),
            "trojan": client.get("password"), "shadowsocks": client.get("email")}[protocol]


class XuiAdapter(PanelAdapter):
    def __init__(self, node: "NodeConfig", transport: Transport | None = None, limit_ip: int = 0,
                 inbound_cache_ttl: float = 30.0):
        self.key = node.key
        self._node = node
        self._base = node.base_url.rstrip("/")
        self._t: Transport = transport or AiohttpTransport(node.verify_ssl)
        self._limit_ip = limit_ip
        self._logged_in = False
        self._csrf: str | None = None
        self._api_token = getattr(node, "api_token", "") or ""
        self._api_mode = (getattr(node, "api_mode", "auto") or "auto").lower()
        self._modern: bool | None = None
        self._login_lock = asyncio.Lock()
        self._io_lock = asyncio.Lock()      # изменения клиентов в одной панели — строго по очереди
        self._cache: dict[int, tuple[float, dict]] = {}
        self._links_cache: dict[str, tuple[float, list[str]]] = {}
        self._ttl = inbound_cache_ttl

    # ---------- HTTP / вход ----------
    @staticmethod
    def _parse_csrf(body: Any, text: str) -> str | None:
        keys = ("csrfToken", "csrf_token", "csrf", "token")
        if isinstance(body, dict):
            obj = body.get("obj")
            if isinstance(obj, str) and obj:
                return obj
            for src in (obj, body):
                if isinstance(src, dict):
                    for k in keys:
                        if isinstance(src.get(k), str) and src[k]:
                            return src[k]
        t = (text or "").strip()
        if 8 <= len(t) <= 256 and " " not in t and "<" not in t and "{" not in t:
            return t
        return None

    async def _fetch_csrf(self) -> str | None:
        """Панели 3.x требуют CSRF-токен: GET /csrf-token → заголовок X-CSRF-Token. Старые панели → 404."""
        status, body, text = await self._t.request("GET", f"{self._base}/csrf-token")
        return self._parse_csrf(body, text) if status == 200 else None

    async def _login(self) -> None:
        async with self._login_lock:
            if self._api_token:                   # токен API: вход не нужен, CSRF не проверяется
                self._logged_in = True
                return
            self._csrf = await self._fetch_csrf()
            headers = {"X-CSRF-Token": self._csrf} if self._csrf else None
            status, body, text = await self._t.request(
                "POST", f"{self._base}/login", headers=headers,
                form={"username": self._node.username, "password": self._node.password})
            if status != 200 or not isinstance(body, dict) or not body.get("success"):
                msg = body.get("msg") if isinstance(body, dict) else f"HTTP {status}"
                raise PanelAuthError(f"[{self.key}] вход в панель не удался: {msg}")
            self._logged_in = True

    def _auth_headers(self, method: str) -> dict:
        if self._api_token:
            return {"Authorization": f"Bearer {self._api_token}"}
        if self._csrf and method.upper() not in ("GET", "HEAD"):
            return {"X-CSRF-Token": self._csrf}
        return {}

    async def _call_full(self, method: str, path: str, *, json_body: Any = None, _retry: bool = True) -> dict:
        """Возвращает JSON-ответ панели как есть (success может быть false). Бросает PanelError на HTTP/не-JSON."""
        if not self._logged_in:
            await self._login()
        status, body, text = await self._t.request(method, f"{self._base}{path}", json_body=json_body,
                                                   headers=self._auth_headers(method) or None)
        # без сессии/с устаревшим CSRF панель отвечает 401/403/404 → перелогин (новый CSRF) и один повтор
        if status in (401, 403, 404) and _retry:
            self._logged_in = False
            self._csrf = None
            return await self._call_full(method, path, json_body=json_body, _retry=False)
        if status >= 400:
            raise PanelError(f"[{self.key}] HTTP {status} на {path.split('?')[0]}")
        if not isinstance(body, dict):
            raise PanelError(f"[{self.key}] ответ панели не JSON на {path.split('?')[0]}")
        return body

    async def _call(self, method: str, path: str, *, json_body: Any = None) -> Any:
        body = await self._call_full(method, path, json_body=json_body)
        if not body.get("success"):
            raise PanelError(f"[{self.key}] панель отклонила запрос {path.split('?')[0]}: "
                             f"{body.get('msg') or 'без сообщения'}")
        return body.get("obj")

    async def _get_inbound(self, pid: int, fresh: bool = False) -> dict:
        hit = self._cache.get(pid)
        if hit and not fresh and time.monotonic() - hit[0] < self._ttl:
            return hit[1]
        obj = await self._call("GET", f"/panel/api/inbounds/get/{pid}")
        if not isinstance(obj, dict):
            raise PanelError(f"[{self.key}] inbound {pid} не найден")
        self._cache[pid] = (time.monotonic(), obj)
        return obj

    # ---------- какой API у панели ----------
    async def _is_modern(self) -> bool:
        if self._modern is not None:
            return self._modern
        if self._api_mode in ("modern", "legacy"):
            self._modern = self._api_mode == "modern"
            return self._modern
        for path in ("/panel/api/clients/list/paged?page=1&pageSize=1", "/panel/api/clients/list"):
            try:
                await self._call("GET", path)
                self._modern = True
                break
            except PanelAuthError:
                raise
            except PanelError as e:
                if "HTTP 404" in str(e):       # маршрута нет → пробуем дальше / старый API
                    continue
                self._modern = True            # маршрут есть, но панель вернула отказ (права и т.п.)
                break
        else:
            self._modern = False
        log.info("[%s] API панели: %s", self.key, "современный (clients/*)" if self._modern else "старый (inbounds/*)")
        return self._modern

    # ================= СОВРЕМЕННЫЙ API (3.x) =================
    @staticmethod
    def _split_modern(obj: Any) -> tuple[dict, list[int]] | None:
        if isinstance(obj, list):
            obj = obj[0] if obj else None
        if not isinstance(obj, dict) or not obj:
            return None
        c = obj.get("client") if isinstance(obj.get("client"), dict) else obj
        ids = obj.get("inboundIds") or c.get("inboundIds") or []
        return c, [int(i) for i in ids if str(i).lstrip("-").isdigit()]

    async def _modern_get(self, email: str) -> tuple[dict, list[int]] | None:
        body = await self._call_full("GET", f"/panel/api/clients/get/{quote(email, safe='')}")
        if not body.get("success"):
            return None
        return self._split_modern(body.get("obj"))

    @staticmethod
    def _modern_secret(c: dict, email: str) -> str:
        for k in ("uuid", "password", "auth"):
            if isinstance(c.get(k), str) and c[k]:
                return c[k]
        return c["id"] if isinstance(c.get("id"), str) and c["id"] else email

    async def _ensure_modern(self, pid, email, secret, expiry_ms, enabled, comment, sub_id) -> ClientState:
        inbound = await self._get_inbound(pid, fresh=True)
        protocol = (inbound.get("protocol") or "").lower()
        q = quote(email, safe="")
        existing = await self._modern_get(email)
        if existing is None:
            client: dict = {"email": email, "enable": enabled, "expiryTime": expiry_ms, "limitIp": self._limit_ip,
                            "totalGB": 0, "comment": comment, "tgId": 0}
            if sub_id:
                client["subId"] = sub_id
            if protocol == "vless":
                stream = links.loads(inbound.get("streamSettings"))
                if (stream.get("network") or "tcp") == "tcp" and stream.get("security") in ("reality", "tls"):
                    client["flow"] = "xtls-rprx-vision"
            if secret and protocol in ("vless", "vmess"):
                client["id"] = secret
            await self._call("POST", "/panel/api/clients/add", json_body={"client": client, "inboundIds": [pid]})
            created = True
        else:
            c, inb_ids = existing
            if pid not in inb_ids:
                await self._call("POST", f"/panel/api/clients/{q}/attach", json_body={"inboundIds": [pid]})
            upd: dict = {"email": email, "enable": enabled, "expiryTime": expiry_ms}
            if sub_id and c.get("subId") != sub_id:
                upd["subId"] = sub_id
            await self._call("POST", f"/panel/api/clients/update/{q}", json_body=upd)
            created = False
        after = await self._modern_get(email)             # проверяем, что панель ПРИМЕНИЛА изменения
        if after is None:
            raise PanelError(f"[{self.key}] клиент {email} не найден после записи")
        c, inb_ids = after
        if int(c.get("expiryTime", -1)) != expiry_ms or bool(c.get("enable")) != bool(enabled) or pid not in inb_ids:
            raise PanelError(f"[{self.key}] панель не применила изменения клиента {email}")
        self._links_cache.pop(email, None)
        return ClientState(self._modern_secret(c, email), protocol, links.protocol_label(inbound),
                           expiry_ms // 1000, bool(c.get("enable")), created)

    @staticmethod
    def _fix_link(link: str, public_host: str, remark: str) -> str:
        """Подставляет наш хост (если панель отдала 0.0.0.0/localhost) и своё имя подключения."""
        if link.startswith("vmess://") or "://" not in link:
            return link
        p = urlsplit(link)
        netloc = p.netloc
        if p.hostname in BAD_HOSTS and public_host:
            netloc = netloc.replace(p.hostname or "", public_host, 1) if p.hostname else public_host
        return urlunsplit((p.scheme, netloc, p.path, p.query, quote(remark, safe="")))

    async def _modern_links(self, email: str) -> list[str]:
        hit = self._links_cache.get(email)
        if hit and time.monotonic() - hit[0] < self._ttl:
            return hit[1]
        obj = await self._call("GET", f"/panel/api/clients/links/{quote(email, safe='')}")
        urls = [u for u in (obj or []) if isinstance(u, str) and u]
        self._links_cache[email] = (time.monotonic(), urls)
        return urls

    # ================= СТАРЫЙ API (2.x) =================
    def _new_client(self, protocol: str, inbound: dict, email: str, secret: str | None,
                    expiry_ms: int, enabled: bool, comment: str, sub_id: str = "") -> dict:
        base = {"email": email, "limitIp": self._limit_ip, "totalGB": 0, "expiryTime": expiry_ms,
                "enable": enabled, "tgId": "", "subId": sub_id or _secrets.token_hex(8), "comment": comment, "reset": 0}
        if protocol == "vless":
            stream = links.loads(inbound.get("streamSettings"))
            flow = ""
            if (stream.get("network") or "tcp") == "tcp" and (stream.get("security") in ("reality", "tls")):
                flow = "xtls-rprx-vision"
            return {"id": secret or str(uuid.uuid4()), "flow": flow, **base}
        if protocol == "vmess":
            return {"id": secret or str(uuid.uuid4()), "security": "auto", **base}
        if protocol == "trojan":
            return {"password": secret or _secrets.token_urlsafe(12), **base}
        if protocol == "shadowsocks":
            method = links.loads(inbound.get("settings")).get("method", "")
            if method.startswith("2022-blake3-aes-128"):
                pw = base64.b64encode(_secrets.token_bytes(16)).decode()
            elif method.startswith("2022-"):
                pw = base64.b64encode(_secrets.token_bytes(32)).decode()
            else:
                pw = _secrets.token_urlsafe(12)
            return {"method": method, "password": secret or pw, **base}
        raise UnsupportedProtocol(f"[{self.key}] протокол '{protocol}' не поддерживается")

    @staticmethod
    def _find(inbound: dict, email: str) -> dict | None:
        for c in links.loads(inbound.get("settings")).get("clients", []) or []:
            if c.get("email") == email:
                return c
        return None

    async def _ensure_legacy(self, pid, email, secret, expiry_ms, enabled, comment, sub_id) -> ClientState:
        inbound = await self._get_inbound(pid, fresh=True)
        protocol = (inbound.get("protocol") or "").lower()
        if protocol not in SUPPORTED:
            raise UnsupportedProtocol(f"[{self.key}] inbound {pid}: протокол '{protocol}' "
                                      f"не поддерживается (поддерживаются: {', '.join(sorted(SUPPORTED))})")
        existing = self._find(inbound, email)
        if existing is None:
            client = self._new_client(protocol, inbound, email, secret, expiry_ms, enabled, comment, sub_id)
            await self._call("POST", "/panel/api/inbounds/addClient",
                             json_body={"id": pid, "settings": json.dumps({"clients": [client]})})
            created = True
        else:
            client = {**existing, "expiryTime": expiry_ms, "enable": enabled}
            if sub_id:
                client["subId"] = sub_id
            if self._limit_ip and not client.get("limitIp"):
                client["limitIp"] = self._limit_ip
            await self._call("POST", f"/panel/api/inbounds/updateClient/{_client_key(protocol, existing)}",
                             json_body={"id": pid, "settings": json.dumps({"clients": [client]})})
            created = False
        self._cache.pop(pid, None)
        after = await self._get_inbound(pid, fresh=True)
        got = self._find(after, email)
        if got is None:
            raise PanelError(f"[{self.key}] клиент {email} не найден после записи")
        if int(got.get("expiryTime", -1)) != expiry_ms or bool(got.get("enable")) != bool(enabled):
            raise PanelError(f"[{self.key}] панель не применила изменения клиента {email}")
        return ClientState(_client_key(protocol, got), protocol, links.protocol_label(after),
                           expiry_ms // 1000, bool(got.get("enable")), created)

    # ================= общий интерфейс =================
    async def ensure_client(self, panel_inbound_id, email, secret, expiry_ts, enabled, comment="", sub_id=""):
        expiry_ms = int(expiry_ts) * 1000
        async with self._io_lock:
            if await self._is_modern():
                return await self._ensure_modern(panel_inbound_id, email, secret, expiry_ms, enabled, comment, sub_id)
            return await self._ensure_legacy(panel_inbound_id, email, secret, expiry_ms, enabled, comment, sub_id)

    async def get_client(self, panel_inbound_id, email):
        inbound = await self._get_inbound(panel_inbound_id, fresh=True)
        protocol = (inbound.get("protocol") or "").lower()
        if await self._is_modern():
            got = await self._modern_get(email)
            if got is None or panel_inbound_id not in got[1]:
                return None
            c = got[0]
            return ClientState(self._modern_secret(c, email), protocol, links.protocol_label(inbound),
                               int(c.get("expiryTime", 0)) // 1000, bool(c.get("enable")))
        c = self._find(inbound, email)
        if c is None:
            return None
        return ClientState(_client_key(protocol, c), protocol, links.protocol_label(inbound),
                           int(c.get("expiryTime", 0)) // 1000, bool(c.get("enable")))

    async def build_link(self, panel_inbound_id, email, secret, remark):
        inbound = await self._get_inbound(panel_inbound_id)
        if await self._is_modern():
            urls = await self._modern_links(email)       # ссылку собирает САМА панель — формат всегда верный
            if not urls:
                raise PanelError(f"[{self.key}] панель не вернула ссылку для {email}")
            return LinkInfo(links.protocol_label(inbound), self._fix_link(urls[0], self._node.public_host, remark))
        client = self._find(inbound, email)
        if client is None:
            raise PanelError(f"[{self.key}] клиент {email} не найден в панели")
        return LinkInfo(links.protocol_label(inbound),
                        links.build_link(inbound, self._node.public_host, client, remark))

    async def close(self):
        await self._t.close()
