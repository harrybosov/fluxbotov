"""Реестр узлов: адаптеры + синхронизация конфигурации узлов/inbound'ов в БД."""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from config import NodeConfig, Settings
from utils import clock
from vpn.base import PanelAdapter

COUNTRIES = {  # код → (флаг, название RU, название EN для remark)
    "DE": ("🇩🇪", "Германия", "Germany"),
    "US": ("🇺🇸", "США", "USA"),
}
COUNTRY_ORDER = {"DE": 0, "US": 1}


def country_meta(code: str) -> tuple[str, str, str]:
    return COUNTRIES.get(code.upper(), ("🌐", code.title(), code.title()))


class NodeRegistry:
    def __init__(self, db, nodes: list[NodeConfig], adapters: dict[str, PanelAdapter]):
        self.db = db
        self.nodes = {n.key: n for n in nodes}
        self.adapters = adapters

    @classmethod
    def from_settings(cls, db, settings: Settings) -> "NodeRegistry":
        adapters: dict[str, PanelAdapter] = {}
        for n in settings.nodes:
            if settings.vpn_mode == "xui":
                from vpn.xui_adapter import XuiAdapter
                adapters[n.key] = XuiAdapter(n, limit_ip=settings.vpn_limit_ip)
            else:
                from vpn.mock_adapter import MockAdapter
                adapters[n.key] = MockAdapter(n.key)
        return cls(db, settings.nodes, adapters)

    def adapter(self, node_key: str) -> PanelAdapter:
        return self.adapters[node_key]

    async def sync_db(self) -> None:
        """Приводит vpn_nodes/vpn_inbounds в соответствие с конфигурацией (секреты в БД не пишутся)."""
        now = clock.now()
        async with self.db.tx() as t:
            await t.execute("UPDATE vpn_nodes SET is_active=0")
            await t.execute("UPDATE vpn_inbounds SET is_active=0")
            for n in self.nodes.values():
                await t.execute(
                    "INSERT INTO vpn_nodes(key,country,public_host,is_active,created_at) VALUES(?,?,?,1,?) "
                    "ON CONFLICT(key) DO UPDATE SET country=excluded.country, "
                    "public_host=excluded.public_host, is_active=1", (n.key, n.country, n.public_host, now))
                node = await t.fetchone("SELECT id FROM vpn_nodes WHERE key=?", (n.key,))
                for pos, pid in enumerate(n.inbound_ids, start=1):
                    await t.execute(
                        "INSERT INTO vpn_inbounds(node_id,panel_inbound_id,position,is_active) VALUES(?,?,?,1) "
                        "ON CONFLICT(node_id,panel_inbound_id) DO UPDATE SET position=excluded.position, is_active=1",
                        (node["id"], pid, pos))

    async def active_inbounds(self) -> list[dict]:
        rows = await self.db.fetchall(
            "SELECT i.id AS inbound_id, i.panel_inbound_id, i.position, i.protocol, "
            "n.key AS node_key, n.country, n.public_host FROM vpn_inbounds i "
            "JOIN vpn_nodes n ON n.id=i.node_id WHERE i.is_active=1 AND n.is_active=1")
        rows.sort(key=lambda r: (COUNTRY_ORDER.get(r["country"], 99), r["node_key"], r["position"]))
        return rows

    async def close(self) -> None:
        for a in self.adapters.values():
            await a.close()
