"""Получение OAuth-токена DonationAlerts (однократно):  python -m scripts.da_auth
Нужны DONATEALERTS_CLIENT_ID / CLIENT_SECRET и redirect URI, указанный в приложении
(https://www.donationalerts.com/application/clients). Права: oauth-donation-index."""
import json
import os
import sys
import time
import urllib.parse
import urllib.request

from dotenv import load_dotenv

from config import BASE_DIR, abs_path

load_dotenv(BASE_DIR / ".env")
cid, secret = os.environ.get("DONATEALERTS_CLIENT_ID", ""), os.environ.get("DONATEALERTS_CLIENT_SECRET", "")
if not cid or not secret:
    sys.exit("Заполните DONATEALERTS_CLIENT_ID и DONATEALERTS_CLIENT_SECRET в .env")
redirect = input("Redirect URI (как в настройках приложения): ").strip()
url = "https://www.donationalerts.com/oauth/authorize?" + urllib.parse.urlencode(
    {"client_id": cid, "redirect_uri": redirect, "response_type": "code", "scope": "oauth-donation-index"})
print("\n1) Откройте ссылку и разрешите доступ:\n", url)
code = input("\n2) Вставьте параметр code из адреса, на который вас перенаправили: ").strip()
data = urllib.parse.urlencode({"grant_type": "authorization_code", "client_id": cid, "client_secret": secret,
                               "redirect_uri": redirect, "code": code}).encode()
with urllib.request.urlopen(urllib.request.Request("https://www.donationalerts.com/oauth/token", data=data)) as r:
    tok = json.load(r)
path = abs_path(os.environ.get("DONATEALERTS_TOKEN_FILE", "data/donatealerts_token.json"))
path.parent.mkdir(parents=True, exist_ok=True)
path.write_text(json.dumps({"access_token": tok["access_token"], "refresh_token": tok.get("refresh_token", ""),
                            "expires_at": int(time.time()) + int(tok.get("expires_in", 3600))}))
path.chmod(0o600)
print("Готово, токен сохранён в", path)
