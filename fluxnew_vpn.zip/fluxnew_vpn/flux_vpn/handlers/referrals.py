from aiogram import F, Router
from aiogram.types import CallbackQuery

from keyboards import btn, home, kb
from utils import texts
from utils.ui import alert, render

router = Router(name="referrals")
E = texts.E


@router.callback_query(F.data == "ref")
async def ref(cb: CallbackQuery, svc, user):
    st = await svc.referrals.stats(user["id"])
    bonus = await svc.kv.get_int("referral_bonus_days", 0)
    tz = svc.settings.timezone
    hist = await svc.referrals.history(user["id"], 5)
    lines = ["🎁 <b>Реферальная программа</b>", "",
             f"За каждого друга, который оплатит подписку, вы получите <b>{texts.fmt_days(bonus)}</b> "
             "(бонус начисляется после первой подтверждённой покупки).", "",
             "🔗 Ваша ссылка:", f"<code>{await svc.referrals.link(user['tg_id'])}</code>", "",
             f"👥 Приглашено: <b>{st['invited']}</b>", f"✅ Подтверждённых покупок: <b>{st['purchases']}</b>",
             f"💎 Бонусный баланс: <b>{texts.fmt_days(st['balance_days'])}</b>"]
    if hist:
        lines += ["", "🧾 История начислений:"]
        for h in hist:
            who = h["username"] and f"@{E(h['username'])}" or E(h["first_name"] or "пользователь")
            lines.append(f"• {texts.fmt_date(h['rewarded_at'], tz)} — {who}: +{texts.fmt_days(h['bonus_days'])}")
    rows = []
    if st["balance_days"] > 0:
        rows.append([btn(f"🎁 Применить {texts.fmt_days(st['balance_days'])}", "ref_claim", style="success")])
    rows.append([home()])
    await render(cb, "\n".join(lines), kb(rows))


@router.callback_query(F.data == "ref_claim")
async def claim(cb: CallbackQuery, svc, user):
    res = await svc.referrals.claim_balance(user["id"])
    if not res:
        return await alert(cb, "Бонусный баланс пуст")
    days, sub = res
    await svc.fulfillment.finish_grant(user["id"])
    text = texts.n_promo(days, texts.fmt_dt(sub["ends_at"], svc.settings.timezone)).replace(
        "🎟 Промокод применён", "🎁 Бонусные дни применены")
    await render(cb, text, kb([[btn("🔑 Мои подключения", "conns", style="success")], [home()]]))
