from aiogram import Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from keyboards import main_menu

router = Router(name="start")

MAIN_TEXT = (
    "💎 <b>FLUX VPN</b>\n\n"
    "🌍 6 серверов: Германия и США\n"
    "🔒 Защищённое подключение\n"
    "🔗 Одна ссылка-подписка на все серверы\n"
    "🚀 Высокая скорость соединения"
)   # свой текст: правьте строки выше (HTML: <b>жирный</b>)


@router.message(CommandStart())
async def start(msg: Message, state: FSMContext, is_new: bool, is_admin: bool):
    await state.clear()
    await msg.answer(MAIN_TEXT, reply_markup=main_menu(is_admin))


@router.message(Command("menu"))
async def menu_cmd(msg: Message, state: FSMContext, is_admin: bool):
    await state.clear()
    await msg.answer(MAIN_TEXT, reply_markup=main_menu(is_admin))
