from aiogram import F, Router
from aiogram.types import CallbackQuery

from keyboards import btn, home, kb
from utils.ui import render

router = Router(name="support")


@router.callback_query(F.data == "support")
async def support(cb: CallbackQuery, svc):
    name = svc.settings.support_username
    rows = []
    if name:
        text = "🆘 <b>Поддержка</b>\n\nПроблемы с оплатой или подключением? Напишите нам — поможем."
        rows.append([btn("✉️ Написать в поддержку", url=f"https://t.me/{name}", style="success")])
    else:
        text = "🆘 <b>Поддержка</b>\n\nКонтакт поддержки пока не настроен."
    rows.append([home()])
    await render(cb, text, kb(rows))
