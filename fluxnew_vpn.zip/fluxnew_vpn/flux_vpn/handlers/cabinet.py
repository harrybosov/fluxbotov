from aiogram import F, Router
from aiogram.types import CallbackQuery

from keyboards import btn, cabinet_kb, home, kb
from models import PROVIDER_TITLES
from utils import texts
from utils.ui import render

router = Router(name="cabinet")
E = texts.E


@router.callback_query(F.data == "cabinet")
async def cabinet(cb: CallbackQuery, svc, user):
    tz = svc.settings.timezone
    sub = await svc.subs.view(user["id"])
    name = " ".join(x for x in (user.get("first_name"), user.get("last_name")) if x) or "—"
    lines = ["👤 <b>Личный кабинет</b>", "",
             f"🆔 Telegram ID: <code>{user['tg_id']}</code>",
             f"👤 Имя: {E(name)}" + (f" (@{E(user['username'])})" if user.get("username") else "")]
    active = False
    if not sub:
        lines += ["", "📦 Тариф: —", "📊 Статус: <b>нет подписки</b>"]
    else:
        active = sub["is_active"]
        plan = await svc.plans.get(sub["plan_id"]) if sub["plan_id"] else None
        lines += ["", f"📦 Тариф: <b>{E(plan['name']) if plan else 'Бонусные дни'}</b>",
                  f"🛒 Дата покупки: {texts.fmt_dt(sub['purchased_at'], tz)}",
                  f"📅 Действует до: <b>{texts.fmt_dt(sub['ends_at'], tz)}</b>",
                  f"⏳ Осталось: {texts.fmt_remaining(sub['remaining'])}",
                  f"📊 Статус: {'🟢 <b>активна</b>' if active else '🔴 <b>истекла</b>'}",
                  f"🔌 Подключений: <b>{await svc.vpn.count_clients(user['id']) if active else 0}</b>"]
        if not active:
            lines += ["", "⚠️ Подписка закончилась. Продлите её, чтобы вернуть доступ."]
    await render(cb, "\n".join(lines), cabinet_kb(active))


@router.callback_query(F.data == "history")
async def history(cb: CallbackQuery, svc, user):
    orders = await svc.orders.list_for_user(user["id"], 10)
    tz = svc.settings.timezone
    if not orders:
        text = "🧾 <b>История платежей</b>\n\nПока пусто."
    else:
        rows = [f"{texts.STATUS_EMOJI[o['status']]} {texts.fmt_dt(o['created_at'], tz)} · {E(o['plan_name'])} · "
                f"{texts.fmt_money(o['amount'], o['currency'])} · {PROVIDER_TITLES[o['provider']]} · "
                f"<code>{o['public_id']}</code>" for o in orders]
        text = "🧾 <b>История платежей</b> (последние 10)\n\n" + "\n".join(rows)
    await render(cb, text, kb([[btn("🔙 В кабинет", "cabinet", style="danger")], [home()]]))
