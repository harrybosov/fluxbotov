import logging

from aiogram import F, Router
from aiogram.types import BufferedInputFile, CallbackQuery

from keyboards import btn, conn_kb, conns_kb, home, kb
from utils import texts
from utils.qr import make_qr_png
from utils.ui import alert, render
from vpn.nodes import country_meta

log = logging.getLogger(__name__)
router = Router(name="connections")
E = texts.E

HELP = ("📖 <b>Как подключиться</b>\n\n"
        "1. Установите VPN-клиент с поддержкой VLESS (например v2rayNG, Hiddify, Streisand, Happ).\n"
        "2. Откройте «🔑 Мои подключения» и выберите подключение.\n"
        "3. Проще всего — «📥 Одна подписка»: одна ссылка сразу на все 6 серверов. Либо скопируйте отдельную ссылку / отсканируйте QR.\n"
        "4. В приложении выберите «Импорт из буфера обмена» / «Сканировать QR» и включите VPN.\n\n"
        "Подписка даёт 6 подключений — если одно работает хуже, переключитесь на другую страну или номер.\n"
        "Не делитесь ссылками: они привязаны к вашей подписке.")


def _detail(v) -> str:
    t = [f"<b>{v.title}</b>", f"Протокол: {E(v.protocol_label)}"]
    if v.is_placeholder:
        t.append("🧪 <i>Тестовая заглушка — это не рабочая конфигурация (VPN_MODE=mock).</i>")
    if v.error:
        t.append(f"⚠️ {v.error}")
    if v.link:
        t += ["", "Ссылка (нажмите, чтобы скопировать):", f"<code>{E(v.link)}</code>"]
    return "\n".join(t)


@router.callback_query(F.data == "conns")
async def conns(cb: CallbackQuery, svc, user):
    views = await svc.vpn.connections(user["id"])
    if not views:
        sub = await svc.subs.view(user["id"])
        text = ("🔑 <b>Мои подключения</b>\n\nУ вас нет активной подписки." if not sub or not sub["is_active"]
                else "🔑 Подключения готовятся — обычно это занимает не больше минуты.")
        return await render(cb, text, kb([[btn("🛒 Купить подписку", "shop", style="success")], [home()]]))
    await render(cb, "🔑 <b>Мои подключения</b>\n\nВыберите подключение:", conns_kb(views))


@router.callback_query(F.data.startswith("conn:"))
async def conn(cb: CallbackQuery, svc, user):
    iid = int(cb.data.split(":")[1])
    view = next((v for v in await svc.vpn.connections(user["id"]) if v.inbound_id == iid), None)
    if not view:
        return await alert(cb, "Подключение недоступно")
    await render(cb, _detail(view), conn_kb(view))


@router.callback_query(F.data.startswith("qr:"))
async def qr(cb: CallbackQuery, svc, user):
    iid = int(cb.data.split(":")[1])
    view = next((v for v in await svc.vpn.connections(user["id"]) if v.inbound_id == iid), None)
    if not view or not view.link:
        return await alert(cb, "Подключение недоступно")
    png = make_qr_png(view.link)
    await cb.message.answer_photo(BufferedInputFile(png, "flux-qr.png"), caption=view.title)
    await cb.answer()


@router.callback_query(F.data == "conns_all")
async def conns_all(cb: CallbackQuery, svc, user):
    views = [v for v in await svc.vpn.connections(user["id"]) if v.link]
    if not views:
        return await alert(cb, "Подключения недоступны")
    by_country: dict[str, list] = {}
    for v in views:
        by_country.setdefault(v.country, []).append(v)
    for code, items in by_country.items():
        flag, ru, _ = country_meta(code)
        body = "\n\n".join(f"<b>Подключение {v.position}</b> · {E(v.protocol_label)}\n<code>{E(v.link)}</code>"
                           for v in items)
        await cb.message.answer(f"{flag} <b>{ru}</b>\n\n{body}")
    await cb.answer()


async def _sub_url(svc, user) -> str | None:
    """Единая ссылка-подписка: сначала подписка самой панели (XUI_SUB_URL), затем лента бота (PUBLIC_URL)."""
    token = await svc.users.sub_token(user["id"])
    if svc.settings.xui_sub_url:
        return f"{svc.settings.xui_sub_url}/{token}"
    if svc.settings.public_url:
        return f"{svc.settings.public_url}/sub/{token}"
    return None


@router.callback_query(F.data == "sublink")
async def sublink(cb: CallbackQuery, svc, user):
    """Единая подписка: одна ссылка (или один блок текста) со всеми 6 серверами."""
    views = [v for v in await svc.vpn.connections(user["id"]) if v.link]
    if not views:
        return await alert(cb, "Подключения пока недоступны")
    note = ("\n🧪 <i>Тестовый режим: это заглушки, а не рабочие конфигурации.</i>"
            if any(v.is_placeholder for v in views) else "")
    back_kb = [btn("📖 Как подключиться", "help")], [btn("🔙 К подключениям", "conns", style="danger")]
    url = await _sub_url(svc, user)
    if url:
        rows = [[btn("📋 Копировать ссылку", copy=url)], [btn("🔳 QR-код", "subqr")], *back_kb]
        text = ("📥 <b>Единая подписка</b>\n\nДобавьте эту ссылку в VPN-приложение как <b>подписку</b> "
                "(«Добавить подписку» / «Import subscription») — подтянутся все 6 серверов сразу, "
                "а при продлении обновятся сами.\n\n"
                f"<code>{E(url)}</code>\n\n⚠️ Ссылка личная, не передавайте её другим.{note}")
        return await render(cb, text, kb(rows))
    body = "\n".join(v.link for v in views)
    if len(body) > 3500:
        return await conns_all(cb, svc, user)
    await cb.message.answer(
        "📥 <b>Все 6 серверов одним блоком</b>\n\nНажмите на блок ниже — он скопируется целиком. "
        "В приложении выберите «Импорт из буфера обмена»: добавятся все серверы сразу.\n\n"
        f"<code>{E(body)}</code>{note}", reply_markup=kb([*back_kb]))
    await cb.answer()


@router.callback_query(F.data == "subqr")
async def subqr(cb: CallbackQuery, svc, user):
    url = await _sub_url(svc, user)
    if not url:
        return await alert(cb, "Ссылка-подписка не настроена")
    await cb.message.answer_photo(BufferedInputFile(make_qr_png(url), "flux-sub-qr.png"), caption="📥 Единая подписка FLUX VPN")
    await cb.answer()


@router.callback_query(F.data == "help")
async def help_(cb: CallbackQuery):
    await render(cb, HELP, kb([[btn("🔙 К подключениям", "conns", style="danger")], [home()]]))
