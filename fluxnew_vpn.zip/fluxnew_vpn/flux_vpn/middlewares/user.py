"""Регистрация/обновление пользователя, реферальная привязка при первом /start, бан-проверка."""
from __future__ import annotations

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message


def parse_ref(text: str | None) -> int | None:
    """'/start ref_12345' → 12345."""
    if not text or not text.startswith("/start"):
        return None
    parts = text.split(maxsplit=1)
    if len(parts) == 2 and parts[1].startswith("ref_") and parts[1][4:].isdigit():
        return int(parts[1][4:])
    return None


class UserMiddleware(BaseMiddleware):
    def __init__(self, svc):
        self.svc = svc

    async def __call__(self, handler, event, data):
        u = event.from_user
        if u is None or u.is_bot:
            return await handler(event, data)
        ref = parse_ref(event.text) if isinstance(event, Message) else None
        user, created = await self.svc.users.upsert_from_telegram(
            u.id, u.username, u.first_name, u.last_name, ref)
        data["user"], data["is_new"] = user, created
        data["is_admin"] = self.svc.settings.is_admin(u.id)
        # Платёж Stars нельзя терять даже у заблокированного пользователя
        paying = isinstance(event, Message) and event.successful_payment is not None
        if user["is_blocked"] and not data["is_admin"] and not paying:
            if isinstance(event, CallbackQuery):
                await event.answer("Доступ к боту ограничен", show_alert=True)
            return None
        return await handler(event, data)
