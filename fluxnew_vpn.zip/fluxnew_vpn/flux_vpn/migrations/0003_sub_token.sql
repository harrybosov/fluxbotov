-- Личный токен для единой ссылки-подписки (/sub/<token>)
ALTER TABLE users ADD COLUMN sub_token TEXT;
CREATE UNIQUE INDEX idx_users_sub_token ON users(sub_token) WHERE sub_token IS NOT NULL;
