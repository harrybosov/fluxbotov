import tempfile
import unittest
from pathlib import Path

from database import Database
from tests.helpers import MIGRATIONS


class DatabaseTests(unittest.IsolatedAsyncioTestCase):
    async def test_migrations_backup_and_integrity(self):
        with tempfile.TemporaryDirectory() as d:
            db = Database(Path(d) / "t.db")
            await db.connect()
            self.assertEqual(await db.migrate(MIGRATIONS, Path(d) / "bk"), ["0001_init", "0002_seed", "0003_sub_token"])
            self.assertEqual(await db.migrate(MIGRATIONS, Path(d) / "bk"), [])       # повторно — ничего
            tables = {r["name"] for r in await db.fetchall("SELECT name FROM sqlite_master WHERE type='table'")}
            for t in ("users plans subscriptions payments orders referrals promo_codes promo_redemptions "
                      "vpn_nodes vpn_inbounds vpn_clients admin_logs notifications").split():
                self.assertIn(t, tables)
            bk = await db.backup(Path(d) / "bk", keep=2)
            self.assertTrue(bk.exists())
            await db.backup(Path(d) / "bk", keep=2); await db.backup(Path(d) / "bk", keep=2)
            self.assertLessEqual(len(list((Path(d) / "bk").glob("flux-*.db"))), 2)
            await db.close()

    async def test_constraints(self):
        db = Database(":memory:")
        await db.connect(); await db.migrate(MIGRATIONS)
        import sqlite3
        with self.assertRaises(sqlite3.IntegrityError):
            await db.execute("INSERT INTO orders(public_id,user_id,plan_id,plan_name,days,provider,amount,"
                             "currency,status,created_at,expires_at) VALUES('X',99,'m1','n',1,'STARS',1,'XTR',"
                             "'PENDING',1,2)")                                          # FK на users
        await db.execute("INSERT INTO users(tg_id,created_at) VALUES(1,1)")
        with self.assertRaises(sqlite3.IntegrityError):
            await db.execute("INSERT INTO users(tg_id,created_at) VALUES(1,1)")        # UNIQUE tg_id
        with self.assertRaises(sqlite3.IntegrityError):
            await db.execute("UPDATE users SET bonus_days=-1")                         # CHECK
        # откат транзакции при исключении
        try:
            async with db.tx() as t:
                await t.execute("INSERT INTO users(tg_id,created_at) VALUES(2,1)")
                raise RuntimeError("x")
        except RuntimeError:
            pass
        self.assertIsNone(await db.fetchone("SELECT 1 FROM users WHERE tg_id=2"))
        await db.close()
