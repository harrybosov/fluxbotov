"""Общие помощники тестов: БД в памяти, сервисы, фейковый нотификатор и фейковая панель 3X-UI."""
from __future__ import annotations

import json
import unittest
from pathlib import Path
from types import SimpleNamespace

from database import Database
from services.fulfillment import Fulfillment
from services.orders import OrderService
from services.plans import PlanService
from services.promo import PromoService
from services.referrals import REF_BONUS_KEY, ReferralService
from services.settings import SettingsService
from services.subscriptions import SubscriptionService
from services.users import UserService
from utils import clock
from vpn.mock_adapter import MockAdapter
from vpn.nodes import NodeRegistry
from vpn.subscriptions import VpnManager

MIGRATIONS = Path(__file__).resolve().parent.parent / "migrations"
T0 = 1_800_000_000  # фиксированное «сейчас» в тестах
DAY = 86400


class FakeNotifier:
    def __init__(self):
        self.sent: list[tuple[int, str]] = []
        self.admin: list[str] = []
        self._once: set = set()

    async def send(self, tg_id, text, reply_markup=None):
        self.sent.append((tg_id, text))
        return True

    async def once(self, user, kind, ref, text, reply_markup=None):
        key = (user["id"], kind, str(ref))
        if key in self._once:
            return False
        self._once.add(key)
        self.sent.append((user["tg_id"], text))
        return True

    async def mark_only(self, user_id, kind, ref):
        key = (user_id, kind, str(ref))
        if key in self._once:
            return False
        self._once.add(key)
        return True

    async def notify_admins(self, text, reply_markup=None):
        self.admin.append(text)


def make_nodes():
    return [SimpleNamespace(key="DE", country="DE", public_host="de.test", inbound_ids=[1, 2, 3]),
            SimpleNamespace(key="US", country="US", public_host="us.test", inbound_ids=[1, 2, 3])]


class Env:
    pass


class BaseCase(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        clock.freeze(T0)
        e = self.env = Env()
        e.db = Database(":memory:")
        await e.db.connect()
        await e.db.migrate(MIGRATIONS)
        e.settings = SettingsService(e.db)
        await e.settings.set(REF_BONUS_KEY, "3")
        e.users = UserService(e.db)
        e.plans = PlanService(e.db)
        e.subs = SubscriptionService(e.db)
        e.orders = OrderService(e.db, e.plans)
        e.promo = PromoService(e.db)
        e.referrals = ReferralService(e.db)
        e.adapters = {"DE": MockAdapter("DE"), "US": MockAdapter("US")}
        e.registry = NodeRegistry(e.db, make_nodes(), e.adapters)
        await e.registry.sync_db()
        e.vpn = VpnManager(e.db, e.registry)
        e.notifier = FakeNotifier()
        e.fulfillment = Fulfillment(e.db, e.orders, e.subs, e.vpn, e.notifier, e.users, "UTC")

    async def asyncTearDown(self):
        clock.unfreeze()
        await self.env.db.close()

    async def new_user(self, tg_id=1001, ref=None):
        user, _ = await self.env.users.upsert_from_telegram(tg_id, f"u{tg_id}", "Name", None, ref)
        return user

    async def paid_order(self, user, plan_id="m1", ext="ext-1", provider="CRYPTOBOT"):
        order = await self.env.orders.create_order(user["id"], plan_id, provider)
        out = await self.env.fulfillment.confirm(order["id"], source=provider, external_id=ext,
                                                 amount=order["amount"], currency=order["currency"])
        return order, out


class FakePanel:
    """Имитация API 3X-UI: сессия по cookie (без неё /panel/* отвечает 404), JSON {success,msg,obj}."""

    def __init__(self, base: str, inbounds: dict[int, dict]):
        self.base = base
        self.inbounds = inbounds
        self.logged = False
        self.login_ok = True
        self.ignore_updates = False
        self.conn_error = False
        self.reject_msg: str | None = None
        self.require_csrf = False         # панель 3.x: CSRF-токен обязателен
        self.csrf = "CSRF-TOKEN-123"
        self.api_token: str | None = None # панель принимает Authorization: Bearer
        self.modern = False               # панель 3.x: клиенты через /panel/api/clients/*
        self.mclients: dict[str, dict] = {}
        self.calls: list[tuple[str, str]] = []

    def expire_session(self):
        self.logged = False

    async def request(self, method, url, *, json_body=None, form=None, headers=None):
        from vpn.base import PanelConnectionError
        headers = headers or {}
        if self.conn_error:
            raise PanelConnectionError("boom")
        path = url[len(self.base):]
        self.calls.append((method, path))
        if path == "/csrf-token":
            if not self.require_csrf:
                return 404, None, "404 page not found"
            return 200, {"success": True, "obj": self.csrf}, ""
        if path == "/login":
            if self.require_csrf and headers.get("X-CSRF-Token") != self.csrf:
                return 403, None, ""                       # как у реальной панели: пустой ответ
            if self.login_ok and form and form.get("password") == "pw":
                self.logged = True
                return 200, {"success": True, "msg": "ok", "obj": None}, ""
            return 200, {"success": False, "msg": "wrong username or password"}, ""
        bearer = self.api_token and headers.get("Authorization") == f"Bearer {self.api_token}"
        if not (self.logged or bearer):
            return 404, None, "404 page not found"
        if (not bearer) and self.require_csrf and method.upper() == "POST" \
                and headers.get("X-CSRF-Token") != self.csrf:
            return 403, None, ""
        if self.reject_msg:
            return 200, {"success": False, "msg": self.reject_msg}, ""
        if self.modern and path.startswith("/panel/api/clients/"):
            return self._modern(method, path, json_body)
        if self.modern and path.startswith("/panel/api/inbounds/") and "lient" in path:
            return 404, None, "404 page not found"             # старые маршруты клиентов удалены
        if (not self.modern) and path.startswith("/panel/api/clients/"):
            return 404, None, "404 page not found"
        if path.startswith("/panel/api/inbounds/get/"):
            ib = self.inbounds.get(int(path.rsplit("/", 1)[1]))
            if not ib:
                return 200, {"success": False, "msg": "not found"}, ""
            return 200, {"success": True, "obj": self._dump(ib)}, ""
        if path == "/panel/api/inbounds/addClient":
            ib = self.inbounds[json_body["id"]]
            new = json.loads(json_body["settings"])["clients"][0]
            if any(c["email"] == new["email"] for c in ib["settings"]["clients"]):
                return 200, {"success": False, "msg": "Duplicate email: " + new["email"]}, ""
            ib["settings"]["clients"].append(new)
            return 200, {"success": True, "obj": None}, ""
        if path.startswith("/panel/api/inbounds/updateClient/"):
            key = path.rsplit("/", 1)[1]
            ib = self.inbounds[json_body["id"]]
            upd = json.loads(json_body["settings"])["clients"][0]
            for i, c in enumerate(ib["settings"]["clients"]):
                if key in (c.get("id"), c.get("password"), c.get("email")):
                    if not self.ignore_updates:
                        ib["settings"]["clients"][i] = upd
                    return 200, {"success": True, "obj": None}, ""
            return 200, {"success": False, "msg": "client not found"}, ""
        return 404, None, "404"

    def _modern(self, method, path, body):
        from urllib.parse import unquote
        p = path[len("/panel/api/clients/"):]
        if p.startswith("list"):
            return 200, {"success": True, "obj": {"items": []}}, ""
        if p.startswith("get/"):
            c = self.mclients.get(unquote(p[4:]))
            if not c:
                return 200, {"success": False, "msg": "client not found"}, ""
            return 200, {"success": True, "obj": {"client": c["client"], "inboundIds": list(c["inbounds"])}}, ""
        if p == "add":
            cl = dict(body["client"])
            if cl["email"] in self.mclients:
                return 200, {"success": False, "msg": "email already in use"}, ""
            cl.setdefault("uuid", f"uuid-{len(self.mclients) + 1}")
            self.mclients[cl["email"]] = {"client": cl, "inbounds": list(body["inboundIds"])}
            return 200, {"success": True, "msg": "Client added"}, ""
        if p.startswith("update/"):
            c = self.mclients.get(unquote(p[7:]))
            if not c:
                return 200, {"success": False, "msg": "client not found"}, ""
            if not self.ignore_updates:
                c["client"].update(body)
            return 200, {"success": True, "msg": "Client updated"}, ""
        if p.endswith("/attach"):
            c = self.mclients.get(unquote(p[:-7]))
            if not c:
                return 200, {"success": False, "msg": "client not found"}, ""
            for i in body["inboundIds"]:
                if i not in c["inbounds"]:
                    c["inbounds"].append(i)
            return 200, {"success": True}, ""
        if p.startswith("links/"):
            c = self.mclients.get(unquote(p[6:]))
            if not c:
                return 200, {"success": False, "msg": "client not found"}, ""
            urls = [f"vless://{c['client']['uuid']}@0.0.0.0:443?type=tcp&security=reality&pbk=PUB#panel-name-{i}"
                    for i in c["inbounds"]]
            return 200, {"success": True, "obj": urls}, ""
        return 404, None, "404"

    @staticmethod
    def _dump(ib):
        return {"id": ib["id"], "protocol": ib["protocol"], "port": ib["port"], "remark": "r",
                "settings": json.dumps(ib["settings"]), "streamSettings": json.dumps(ib["stream"])}

    async def close(self):
        pass


def reality_inbound(pid=1, protocol="vless"):
    return {"id": pid, "protocol": protocol, "port": 443,
            "settings": {"clients": []},
            "stream": {"network": "tcp", "security": "reality",
                       "realitySettings": {"serverNames": ["www.example.com"], "shortIds": ["ab12"],
                                           "settings": {"publicKey": "PUBKEY", "fingerprint": "chrome",
                                                        "spiderX": "/"}}}}
