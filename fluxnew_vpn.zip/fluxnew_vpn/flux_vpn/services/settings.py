"""Ключ-значение настройки в БД (редактируются из админ-панели)."""
from __future__ import annotations


async def get_value(ex, key: str, default: str | None = None) -> str | None:
    """`ex` — Database или Tx (оба имеют fetchone)."""
    row = await ex.fetchone("SELECT value FROM settings WHERE key=?", (key,))
    return row["value"] if row else default


async def get_int(ex, key: str, default: int = 0) -> int:
    v = await get_value(ex, key)
    try:
        return int(v) if v is not None else default
    except ValueError:
        return default


class SettingsService:
    def __init__(self, db, defaults: dict[str, str] | None = None):
        self.db = db
        self.defaults = defaults or {}

    async def get(self, key: str, default: str | None = None) -> str | None:
        v = await get_value(self.db, key)
        return v if v is not None else self.defaults.get(key, default)

    async def get_int(self, key: str, default: int = 0) -> int:
        v = await self.get(key)
        try:
            return int(v) if v is not None else default
        except ValueError:
            return default

    async def set(self, key: str, value: str) -> None:
        await self.db.execute(
            "INSERT INTO settings(key,value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))
