from __future__ import annotations

import re

from services.subscriptions import extend_tx
from utils import clock

CODE_RE = re.compile(r"^[A-Z0-9_-]{3,32}$")


class PromoError(Exception):
    """Сообщение пригодно для показа пользователю."""


class PromoNotFound(PromoError): ...
class PromoDisabled(PromoError): ...
class PromoExpired(PromoError): ...
class PromoExhausted(PromoError): ...
class PromoAlreadyUsed(PromoError): ...


def normalize(code: str) -> str:
    return (code or "").strip().upper()


class PromoService:
    def __init__(self, db):
        self.db = db

    async def create(self, code: str, bonus_days: int, max_uses: int | None = None,
                     expires_at: int | None = None, once_per_user: bool = True) -> dict:
        code = normalize(code)
        if not CODE_RE.match(code):
            raise ValueError("Код: 3–32 символа, латиница/цифры/_/-")
        if bonus_days <= 0:
            raise ValueError("Количество дней должно быть > 0")
        if max_uses is not None and max_uses <= 0:
            raise ValueError("Лимит должен быть > 0")
        if await self.db.fetchone("SELECT 1 FROM promo_codes WHERE code=?", (code,)):
            raise ValueError("Такой промокод уже существует")
        async with self.db.tx() as t:
            new_id = await t.insert(
                "INSERT INTO promo_codes(code,bonus_days,max_uses,expires_at,once_per_user,created_at) "
                "VALUES(?,?,?,?,?,?)", (code, bonus_days, max_uses, expires_at, int(once_per_user), clock.now()))
            return await t.fetchone("SELECT * FROM promo_codes WHERE id=?", (new_id,))

    async def get(self, promo_id: int) -> dict | None:
        return await self.db.fetchone("SELECT * FROM promo_codes WHERE id=?", (promo_id,))

    async def list(self, limit: int = 30) -> list[dict]:
        return await self.db.fetchall("SELECT * FROM promo_codes ORDER BY id DESC LIMIT ?", (limit,))

    async def set_active(self, promo_id: int, active: bool) -> None:
        await self.db.execute("UPDATE promo_codes SET is_active=? WHERE id=?", (int(active), promo_id))

    async def update(self, promo_id: int, bonus_days: int, max_uses: int | None, expires_at: int | None) -> None:
        if bonus_days <= 0 or (max_uses is not None and max_uses <= 0):
            raise ValueError("Некорректные значения")
        await self.db.execute("UPDATE promo_codes SET bonus_days=?, max_uses=?, expires_at=? WHERE id=?",
                              (bonus_days, max_uses, expires_at, promo_id))

    async def delete(self, promo_id: int) -> None:
        await self.db.execute("DELETE FROM promo_codes WHERE id=?", (promo_id,))

    async def redeem(self, user_id: int, code: str) -> tuple[dict, dict]:
        """Применяет промокод атомарно. Возвращает (промокод, подписка). VPN синхронизирует вызывающий."""
        code = normalize(code)
        now = clock.now()
        async with self.db.tx() as t:
            promo = await t.fetchone("SELECT * FROM promo_codes WHERE code=?", (code,))
            if not promo:
                raise PromoNotFound("Промокод не найден")
            if not promo["is_active"]:
                raise PromoDisabled("Промокод отключён")
            if promo["expires_at"] and promo["expires_at"] <= now:
                raise PromoExpired("Срок действия промокода истёк")
            if promo["max_uses"] is not None and promo["used_count"] >= promo["max_uses"]:
                raise PromoExhausted("Лимит использований промокода исчерпан")
            if promo["once_per_user"]:
                used = await t.fetchone(
                    "SELECT 1 FROM promo_redemptions WHERE promo_id=? AND user_id=?", (promo["id"], user_id))
                if used:
                    raise PromoAlreadyUsed("Вы уже использовали этот промокод")
            n = await t.execute(
                "UPDATE promo_codes SET used_count=used_count+1 WHERE id=? "
                "AND (max_uses IS NULL OR used_count < max_uses)", (promo["id"],))
            if n == 0:
                raise PromoExhausted("Лимит использований промокода исчерпан")
            await t.execute("INSERT INTO promo_redemptions(promo_id,user_id,redeemed_at) VALUES(?,?,?)",
                            (promo["id"], user_id, now))
            sub = await extend_tx(t, user_id, promo["bonus_days"], now=now)
        return promo, sub
