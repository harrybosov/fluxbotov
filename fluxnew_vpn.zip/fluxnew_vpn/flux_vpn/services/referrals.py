from __future__ import annotations

from services import settings as st
from services.subscriptions import extend_tx
from utils import clock

REF_BONUS_KEY = "referral_bonus_days"


async def reward_tx(t, order: dict, now: int | None = None) -> dict | None:
    """Начисляет бонус пригласившему за ПЕРВУЮ подтверждённую покупку приглашённого.
    Повторно за тот же заказ/пользователя начислить нельзя (UNIQUE + условие reward_order_id IS NULL)."""
    now = now if now is not None else clock.now()
    ref = await t.fetchone(
        "SELECT * FROM referrals WHERE referred_id=? AND reward_order_id IS NULL", (order["user_id"],))
    if not ref:
        return None
    bonus = await st.get_int(t, REF_BONUS_KEY, 0)
    if bonus <= 0:
        return None
    n = await t.execute(
        "UPDATE referrals SET reward_order_id=?, bonus_days=?, rewarded_at=? "
        "WHERE id=? AND reward_order_id IS NULL", (order["id"], bonus, now, ref["id"]))
    if n == 0:
        return None
    await t.execute("UPDATE users SET bonus_days = bonus_days + ? WHERE id=?", (bonus, ref["referrer_id"]))
    referrer = await t.fetchone("SELECT * FROM users WHERE id=?", (ref["referrer_id"],))
    return {"referrer": referrer, "bonus_days": bonus}


class ReferralService:
    def __init__(self, db, bot_username_getter=None):
        self.db = db
        self._bot_username = bot_username_getter

    async def link(self, tg_id: int) -> str:
        name = await self._bot_username() if self._bot_username else "bot"
        return f"https://t.me/{name}?start=ref_{tg_id}"

    async def stats(self, user_id: int) -> dict:
        invited = await self.db.fetchone("SELECT COUNT(*) c FROM referrals WHERE referrer_id=?", (user_id,))
        bought = await self.db.fetchone(
            "SELECT COUNT(*) c, COALESCE(SUM(bonus_days),0) s FROM referrals "
            "WHERE referrer_id=? AND reward_order_id IS NOT NULL", (user_id,))
        user = await self.db.fetchone("SELECT bonus_days FROM users WHERE id=?", (user_id,))
        return {"invited": invited["c"], "purchases": bought["c"],
                "earned_days": bought["s"], "balance_days": user["bonus_days"] if user else 0}

    async def history(self, user_id: int, limit: int = 10) -> list[dict]:
        return await self.db.fetchall(
            "SELECT r.bonus_days, r.rewarded_at, u.first_name, u.username FROM referrals r "
            "JOIN users u ON u.id=r.referred_id WHERE r.referrer_id=? AND r.reward_order_id IS NOT NULL "
            "ORDER BY r.rewarded_at DESC LIMIT ?", (user_id, limit))

    async def list_for_admin(self, user_id: int, limit: int = 20) -> list[dict]:
        return await self.db.fetchall(
            "SELECT r.*, u.tg_id, u.username FROM referrals r JOIN users u ON u.id=r.referred_id "
            "WHERE r.referrer_id=? ORDER BY r.created_at DESC LIMIT ?", (user_id, limit))

    async def claim_balance(self, user_id: int) -> tuple[int, dict] | None:
        """Переводит бонусные дни в подписку. Возвращает (дней, подписка) или None, если баланс пуст."""
        async with self.db.tx() as t:
            u = await t.fetchone("SELECT bonus_days FROM users WHERE id=?", (user_id,))
            if not u or u["bonus_days"] <= 0:
                return None
            days = u["bonus_days"]
            await t.execute("UPDATE users SET bonus_days=0 WHERE id=?", (user_id,))
            sub = await extend_tx(t, user_id, days)
        return days, sub
